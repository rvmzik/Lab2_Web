from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),  # маршрут для главной страницы приложения blog
    # Добавьте другие маршруты, если это необходимо
]
