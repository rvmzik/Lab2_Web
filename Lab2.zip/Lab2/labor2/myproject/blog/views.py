from django.shortcuts import render

def index(request):
    return render(request, 'labor2/myproject/blog/templates/blog')  # Убедитесь, что путь правильный
